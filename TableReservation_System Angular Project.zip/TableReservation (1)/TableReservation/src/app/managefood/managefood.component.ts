import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { Delicacies } from '../delicaciesmodel';

@Component({
  selector: 'app-managefood',
  templateUrl: './managefood.component.html',
  styleUrls: ['./managefood.component.css']
})
export class ManagefoodComponent implements OnInit {
  delicacies?:Delicacies[];
  constructor(private router:Router,private adminService:AdminService) { }

  ngOnInit(): void {
    this.adminService.getItems().subscribe(
      data=>{
        this.delicacies=data;
        this.gotoManage();
      }
    );
  }

setEnableItem(id: number){
this.adminService.setEnableItems(id).subscribe();
}

enableItem(id:number){
this.setEnableItem(id);
this.gotoManage();
  }

  disableItem(id:number){
    this.adminService.setDisableItems(id).subscribe();
    this.gotoManage();
  }

  gotoManage(){
    this.router.navigate(['/managefoodlitems'])
  }

}
