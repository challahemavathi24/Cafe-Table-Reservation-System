import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './usermodel';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpclient:HttpClient) { }

  

  getUserLogin(username:string,password:string):Observable<any>{
    return this.httpclient.get("http://localhost:1018/table-reservation/cafe/api/userlogin?username="+username+"&password="+password)
  }
  userRegister(user:Object): Observable<Object>{
    return this.httpclient.post('http://localhost:1018/table-reservation/cafe/api/register',user);
    
    }

    searchTable(tablerow:string):Observable<any>{
      return this.httpclient.get("http://localhost:1018/table-reservation/cafe/api/getTable?tablerow="+tablerow);
    }

    tableBook(id: number): Observable<any>{
      let name=sessionStorage.getItem("name");
      return this.httpclient.get('http://localhost:1018/table-reservation/cafe/api/booktable?id='+id+"&username="+name);
    }

getReservedTable(tableusername:string):Observable<any>{
  return this.httpclient.get("http://localhost:1018/table-reservation/cafe/api/bookedtables?username="+tableusername);
   
}
  user?:User;
    authenticate(username:string, password:string) {
      
      this.getUserLogin(username,password).subscribe(
        data=>{
          this.user=data;
        }
      );
      if (this.user) {
        console.log(this.user?.username)
        sessionStorage.setItem('name', username)
        console.log("username:"+username);
        return true;
      } else {
        return false;
      }
    }
    
    isUserLoggedIn() {
      let name = sessionStorage.getItem('name')
      console.log(!(name === null))
      return !(name === null)
    }
    
    logOut() {
      sessionStorage.removeItem('name')
    }
}
