import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
import { User } from '../usermodel';
import { Tables} from '../tablemodel';

@Component({
  selector: 'app-searchtables',
  templateUrl: './searchtables.component.html',
  styleUrls: ['./searchtables.component.css']
})
export class SearchtablesComponent implements OnInit {
table?:Tables[];

tablerow:string='';

  constructor(private router:Router,private userService:UserService) { }

  ngOnInit(): void {
    this.gotosearch();
  }
  tableSearch(){
  this.userService.searchTable(this.tablerow).subscribe(
    data=>{
      this.table=data;
    }
  );
  }
  
  onTableSearch(){
  this.tableSearch();
  this.gotosearch();
  }
 
  bookTable(id:number){
this.userService.tableBook(id).subscribe();
  }


reserveTable(id:number){
this.bookTable(id);
this.gotosearch();
  }


  gotosearch(){
    this.router.navigate(['/searchtable'])
  }
}
