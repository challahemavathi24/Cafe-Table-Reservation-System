export class Tables{
    id:number=0;
    tablerow:string='';
    tablenumber:string='';
    tablecapacity:string='';
    tableusername:string='';
    tablestatus:string='';

}