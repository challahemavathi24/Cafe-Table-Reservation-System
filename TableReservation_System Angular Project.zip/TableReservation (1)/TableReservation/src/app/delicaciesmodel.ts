export class Delicacies{
    id:number=0;
    itemname:string='';
    itemprice:string='';
    itemdesc:string='';
    status:string='';
}