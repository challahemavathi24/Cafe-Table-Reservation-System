import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { FormsModule } from '@angular/forms';
import { AdddelicaciesComponent } from './adddelicacies/adddelicacies.component';
import { EditdelicaciesComponent } from './editdelicacies/editdelicacies.component';
import { ManagefoodComponent } from './managefood/managefood.component';
import { AdminlogoutComponent } from './adminlogout/adminlogout.component';
import { UserregisterComponent } from './userregister/userregister.component';
import { UserlogoutComponent } from './userlogout/userlogout.component';
import { AddtablesComponent } from './addtables/addtables.component';
import { SearchtablesComponent } from './searchtables/searchtables.component';
import { ViewtablesComponent } from './viewtables/viewtables.component';


@NgModule({
  declarations: [
    AppComponent,
    UserloginComponent,
    AdminloginComponent,
    AdddelicaciesComponent,
    EditdelicaciesComponent,
    ManagefoodComponent,
    AdminlogoutComponent,
    UserregisterComponent,
    UserlogoutComponent,
    AddtablesComponent,
    SearchtablesComponent,
    ViewtablesComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
