import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  baseUrl="http://localhost:1018/table-reservation/cafe/api/";
  constructor(private httpclient:HttpClient) { }


authentication(username:string,password:string){
if(username==="Admin" && password==="Admin"){
sessionStorage.setItem('username',username)
return true;
}else{
  return false;
}
}
addItems(delicacies:Object): Observable<Object>{
return this.httpclient.post('http://localhost:1018/table-reservation/cafe/api/delicacies',delicacies);

}

getItems(): Observable<any>{
  return this.httpclient.get('http://localhost:1018/table-reservation/cafe/api/getdelicacies');
}
removeItemsById(id: number): Observable<any>{
  return this.httpclient.get('http://localhost:1018/table-reservation/cafe/api/removedelicaciesbyid?id='+id);
}

setEnableItems(id: number):Observable<any>{
  return this.httpclient.get('http://localhost:1018/table-reservation/cafe/api/enable?id='+id);
}

setDisableItems(id: number):Observable<any>{
  return this.httpclient.get('http://localhost:1018/table-reservation/cafe/api/Disable?id='+id);
}

addTables(table:Object):Observable<Object>{
  return this.httpclient.post('http://localhost:1018/table-reservation/cafe/api/addtables',table);
}
isAdminLoggedIn() {
  let user = sessionStorage.getItem('username')
  console.log(!(user === null))
  return !(user === null)
}
logOut(){
  sessionStorage.removeItem('username');
}

 
}
