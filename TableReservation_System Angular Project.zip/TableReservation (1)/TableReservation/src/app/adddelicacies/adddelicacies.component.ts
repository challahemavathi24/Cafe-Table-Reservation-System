import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { Delicacies } from '../delicaciesmodel';

@Component({
  selector: 'app-adddelicacies',
  templateUrl: './adddelicacies.component.html',
  styleUrls: ['./adddelicacies.component.css']
})
export class AdddelicaciesComponent implements OnInit {
  delicacies:Delicacies=new Delicacies();
  submitted=false;
  constructor(private router:Router,private adminService:AdminService) { }

  ngOnInit(): void {
    this.gotoAddDelicacies();
  }
  addItemSave(){
    this.adminService.addItems(this.delicacies).subscribe(
      data=>{
        this.delicacies=new Delicacies();
      }
    );
  }
  onSubmit(){
    this.submitted=true;
    this.addItemSave();
  }
  gotoAddDelicacies(){
  this.router.navigate(['/adddelicacies']);
  }

}
