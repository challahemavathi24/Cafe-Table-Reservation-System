import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdddelicaciesComponent } from './adddelicacies.component';

describe('AdddelicaciesComponent', () => {
  let component: AdddelicaciesComponent;
  let fixture: ComponentFixture<AdddelicaciesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdddelicaciesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdddelicaciesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
