import { componentFactoryName } from '@angular/compiler';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdddelicaciesComponent } from './adddelicacies/adddelicacies.component';
import { AdminauthGuardService } from './adminauth-guard.service';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminlogoutComponent } from './adminlogout/adminlogout.component';
import { EditdelicaciesComponent } from './editdelicacies/editdelicacies.component';
import { ManagefoodComponent } from './managefood/managefood.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UserlogoutComponent } from './userlogout/userlogout.component';
import { UserregisterComponent } from './userregister/userregister.component';
import { AddtablesComponent } from './addtables/addtables.component';
import { SearchtablesComponent } from './searchtables/searchtables.component';
import { ViewtablesComponent } from './viewtables/viewtables.component';


const routes: Routes = [
{path:'',redirectTo:'',pathMatch:'full'},
{path:'adminlogin',component:AdminloginComponent},
{path:'adminlogout',component:AdminlogoutComponent,canActivate:[AdminauthGuardService]},
{path:'adddelicacies',component:AdddelicaciesComponent},
{path:'editdelicacies',component:EditdelicaciesComponent},
{path:'managefoodlitems',component:ManagefoodComponent},
{path:'userlogin',component:UserloginComponent},
{path:'userregister',component:UserregisterComponent},
{path:'userlogout',component:UserlogoutComponent},
{path:'addtables',component:AddtablesComponent},
{path:'searchtable',component:SearchtablesComponent},
{path:'viewtable',component:ViewtablesComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
