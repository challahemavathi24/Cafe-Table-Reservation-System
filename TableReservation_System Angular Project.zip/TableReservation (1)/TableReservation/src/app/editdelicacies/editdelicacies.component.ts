import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { AdminauthGuardService } from '../adminauth-guard.service';
import { Delicacies } from '../delicaciesmodel';

@Component({
  selector: 'app-editdelicacies',
  templateUrl: './editdelicacies.component.html',
  styleUrls: ['./editdelicacies.component.css']
})
export class EditdelicaciesComponent implements OnInit {
  delicacies?:Delicacies[];

  constructor(public router:Router,private adminService:AdminService) { }

  ngOnInit(): void {
this.adminService.getItems().subscribe(
  data=>{
    this.delicacies=data;
    this.gotoEditDelicaties();
  }
);
  }

  removingItem(id:number){
    this.adminService.removeItemsById(id).subscribe();
     
}
  removeItem(id:number){
    this.removingItem(id)
    this.ngOnInit(); 
    this.gotoEditDelicaties();
  }
  
  gotoEditDelicaties(){
    this.router.navigate(['editdelicacies']);
  }
}
