import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditdelicaciesComponent } from './editdelicacies.component';

describe('EditdelicaciesComponent', () => {
  let component: EditdelicaciesComponent;
  let fixture: ComponentFixture<EditdelicaciesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditdelicaciesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditdelicaciesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
