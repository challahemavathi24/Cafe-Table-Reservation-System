import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { User } from '../usermodel';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
  username:string='';
  password:string='';
  invalidLogin = false
  user?:User;
  constructor(private router:Router,private userService:UserService) { }

  ngOnInit(): void {
    
  }
  checkUserLogin(){
    if(this.userService.authenticate(this.username,this.password)){
      this.router.navigate(['']);
      this.invalidLogin=false;
      alert("login Successful");
    }else{
      this.invalidLogin=true;
    }
  }
}
