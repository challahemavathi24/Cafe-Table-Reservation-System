package com.reservation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TableResrvationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TableResrvationSystemApplication.class, args);
	}

}
